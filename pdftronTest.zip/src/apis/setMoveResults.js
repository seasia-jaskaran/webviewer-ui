import core from 'core';

export default (results) => {
  core.clearMoveResults();
  core.displayAdditionalMoveResults(results);
};
