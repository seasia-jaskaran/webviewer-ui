import core from 'core';

export default (userName) => {
  core.setCurrentUser(userName);
};
