import core from 'core';

export default () => {
  core.setCurrentPage(1);
};
