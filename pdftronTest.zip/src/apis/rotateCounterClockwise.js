import core from 'core';

export default () => {
  core.rotateCounterClockwise();
};
