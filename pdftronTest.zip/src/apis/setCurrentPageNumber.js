import core from 'core';

export default (pageNumber) => {
  core.setCurrentPage(pageNumber);
};
