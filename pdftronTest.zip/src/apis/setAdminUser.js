import core from 'core';

export default (isAdmin) => {
  core.setIsAdminUser(isAdmin);
};
