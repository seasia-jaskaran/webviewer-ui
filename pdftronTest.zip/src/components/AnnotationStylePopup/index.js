import AnnotationStylePopup from './AnnotationStylePopup';

export default AnnotationStylePopup;