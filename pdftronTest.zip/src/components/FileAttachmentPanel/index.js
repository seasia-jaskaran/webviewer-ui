import FileAttachmentPanel from './FileAttachmentPanel';

export default FileAttachmentPanel;
