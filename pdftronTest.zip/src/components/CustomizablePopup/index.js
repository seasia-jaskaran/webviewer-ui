import CustomizablePopup from './CustomizablePopup';

export default CustomizablePopup;