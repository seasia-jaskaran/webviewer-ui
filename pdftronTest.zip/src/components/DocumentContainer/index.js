import DocumentContainer from './DocumentContainer';

export default DocumentContainer;