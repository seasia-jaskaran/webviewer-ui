import CreatableDropdown from './CreatableDropdown';

export default CreatableDropdown;