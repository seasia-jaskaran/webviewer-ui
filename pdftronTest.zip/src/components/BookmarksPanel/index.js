import BookmarksPanel from './BookmarksPanel';

export default BookmarksPanel;
