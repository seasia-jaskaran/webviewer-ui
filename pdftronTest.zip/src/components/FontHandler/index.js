import FontHandler from './FontHandler';

export default FontHandler;