import ColorPaletteHeader from './ColorPaletteHeader';

export default ColorPaletteHeader;