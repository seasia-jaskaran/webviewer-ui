import BookmarkOutlineContextMenuPopup from './BookmarkOutlineContextMenuPopup';

export default BookmarkOutlineContextMenuPopup;
