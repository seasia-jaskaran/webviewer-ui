import FontSizeDropdown from './FontSizeDropdown';

export default FontSizeDropdown;