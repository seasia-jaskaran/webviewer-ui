import FormFieldIndicator from './FormFieldIndicatorContainer';

export default FormFieldIndicator;
