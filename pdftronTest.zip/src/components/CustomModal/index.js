import CustomModal from './CustomModal';

export default CustomModal;
