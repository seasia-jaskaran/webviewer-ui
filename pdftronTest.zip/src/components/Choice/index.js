import Choice from './Choice';

export default Choice;