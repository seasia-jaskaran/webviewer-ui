import ContentEditModal from './ContentEditModal';

export default ContentEditModal;