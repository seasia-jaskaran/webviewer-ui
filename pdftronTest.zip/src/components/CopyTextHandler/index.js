import CopyTextHandler from './CopyTextHandler';

export default CopyTextHandler;
