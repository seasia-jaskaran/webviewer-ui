import DocumentControls from './DocumentControls';

export default DocumentControls;