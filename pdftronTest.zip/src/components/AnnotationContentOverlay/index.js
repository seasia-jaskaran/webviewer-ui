import AnnotationContentOverlay from './AnnotationContentOverlay';

export default AnnotationContentOverlay;