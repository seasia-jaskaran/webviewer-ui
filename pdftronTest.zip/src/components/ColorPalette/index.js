import ColorPalette from './ColorPalette';

export default ColorPalette;