import CreateStampModal from './CreateStampModal';

export default CreateStampModal;
