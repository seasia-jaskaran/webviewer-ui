import FilterAnnotModal from './FilterAnnotModal';

export default FilterAnnotModal;