import Element from './Element';

export default Element;