import AudioPlaybackPopup from './AudioPlaybackPopupContainer';

export default AudioPlaybackPopup;