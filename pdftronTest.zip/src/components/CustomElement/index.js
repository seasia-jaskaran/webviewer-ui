import CustomElement from './CustomElement';

export default CustomElement;