import ColorPickerModalRedux from './ColorPickerModalRedux';

export default ColorPickerModalRedux;