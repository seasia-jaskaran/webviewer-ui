import CollapsiblePanelGroup from './CollapsiblePanelGroup';

export default CollapsiblePanelGroup;