import DataElementWrapper from './DataElementWrapper';

export default DataElementWrapper;