import CreatableMultiSelect from './CreatableMultiSelect';

export default CreatableMultiSelect;