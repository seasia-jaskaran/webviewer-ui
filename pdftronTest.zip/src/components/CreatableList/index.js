import CreatableList from './CreatableListContainer';

export default CreatableList;