import ContentEditLinkModal from './ContentEditLinkModalContainer';

export default ContentEditLinkModal;