import DocumentCropPopup from './DocumentCropPopupContainer';

export default DocumentCropPopup;