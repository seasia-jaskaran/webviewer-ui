import HorizontalDivider from './HorizontalDivider';

export default HorizontalDivider;