import FilePickerHandler from './FilePickerHandler';

export default FilePickerHandler;
