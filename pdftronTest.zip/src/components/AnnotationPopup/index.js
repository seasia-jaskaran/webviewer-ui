import AnnotationPopup from './AnnotationPopup';

export default AnnotationPopup;