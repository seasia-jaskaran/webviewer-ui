import ColorPalettePickerRedux from './ColorPalettePickerRedux';

export default ColorPalettePickerRedux;