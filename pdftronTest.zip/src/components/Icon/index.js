import Icon from './Icon';

export default Icon;