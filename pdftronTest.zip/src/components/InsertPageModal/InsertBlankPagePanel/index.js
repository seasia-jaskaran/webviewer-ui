import InsertBlankPagePanel from './InsertBlankPagePanel';

export default InsertBlankPagePanel;