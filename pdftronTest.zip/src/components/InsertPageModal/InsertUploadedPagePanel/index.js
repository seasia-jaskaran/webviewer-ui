import InsertUploadedPagePanel from './InsertUploadedPagePanel';

export default InsertUploadedPagePanel;