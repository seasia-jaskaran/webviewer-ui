import InsertPageModal from './InsertPageModal';

export default InsertPageModal;