import AnnotationNoteConnectorLine from './AnnotationNoteConnectorLine';

export default AnnotationNoteConnectorLine;