module.exports = {
  process(src) {
    return src;
  }
};
